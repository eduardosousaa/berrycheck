# berrycheck
 Pacote python de cotacao de moedas e de acoes das principais empresas brasileiras. 
