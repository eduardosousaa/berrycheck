# berrycheck
 Pacote python de cotação de moedas e de ações das principais empresas brasileiras. 
